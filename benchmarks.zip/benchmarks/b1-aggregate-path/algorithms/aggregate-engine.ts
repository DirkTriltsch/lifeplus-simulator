import type { SimulatorInputs } from '@mlm/simulator-core';
import {
  PHASE1,
  PHASE2_RANKS,
  PHASE3_RANKS,
  PRELIM_RANKS,
  REFERRAL_THRESHOLD_IP,
  determineRank,
} from '@mlm/product-lifeplus';
import type { GrowthStrategyName } from '../parameter-sets';

const SIMULATION_YEARS = 10;
const MONTHS_PER_YEAR = 12;
const MAX_EXACT_EFFECTIVE_MEMBERS = 90_000;
const MAX_MONTHLY_VOLUME_EUR = 500_000;

export interface AggregateYearSnapshot {
  year: number;
  activeMembers: number;
  activeShoppers: number;
  totalEffectivePersons: number;
  explicitMemberObjects: number;
  shopperAggregateObjects: number;
  estimatedOrdersPerMonth: number;
  memberMonthlyVolumeIp: number;
  shopperMonthlyVolumeIp: number;
  totalMonthlyVolumeIp: number;
  capped: boolean;
  capReason?: string;
}

export interface LevelDistribution {
  year: number;
  membersByLevel: number[];
  shoppersByLevel: number[];
}

export interface RankDistribution {
  year: number;
  byLevel: Array<Record<string, number>>;
}

export interface PhaseProvisionByYear {
  year: number;
  total: number;
}

export interface RootProvisionByYear {
  year: number;
  total: number;
  rankName: string;
}

export interface ChartDataPoint {
  year: number;
  members: number;
  shoppers: number;
  monthlyVolumeEur: number;
  monthlyProvisionEur: number;
  rootProvisionEur: number;
  capped: boolean;
  capReason?: string;
}

export function applyMandatoryChurnFloor(
  membersPerYear: number,
  attritionRate: number,
): number {
  let floor = 0;
  if (membersPerYear >= 3.5) floor = 0.3;
  else if (membersPerYear >= 3) floor = 0.25;
  else if (membersPerYear >= 2.5) floor = 0.18;
  else if (membersPerYear >= 2) floor = 0.1;
  return Math.max(attritionRate, floor);
}

export function estimateNetworkAggregate(
  inputs: SimulatorInputs,
  options: { years?: number; applyChurnFloor?: boolean } = {},
): AggregateYearSnapshot[] {
  const memberMonthlyVolume = Math.max(0, inputs.memberMonthlyVolume);
  const shopperMonthlyVolume = Math.max(0, inputs.shopperMonthlyVolume);
  const states = simulateAggregateLevels(inputs, options);

  return states.map((state) => {
    const activeMembers = sum(state.membersByLevel);
    const activeShoppers = sum(state.shoppersByLevel);

    const memberMonthlyVolumeIp = activeMembers * memberMonthlyVolume;
    const shopperMonthlyVolumeIp = activeShoppers * shopperMonthlyVolume;
    const totalMonthlyVolumeIp = memberMonthlyVolumeIp + shopperMonthlyVolumeIp;
    const capReason =
      activeMembers > MAX_EXACT_EFFECTIVE_MEMBERS
        ? 'effective_members_cap'
        : totalMonthlyVolumeIp * (inputs.unitToCurrency ?? 1) > MAX_MONTHLY_VOLUME_EUR
          ? 'monthly_volume_cap'
          : undefined;

    return {
      year: state.year,
      activeMembers,
      activeShoppers,
      totalEffectivePersons: activeMembers + activeShoppers,
      explicitMemberObjects: activeMembers,
      shopperAggregateObjects: activeMembers,
      estimatedOrdersPerMonth: activeMembers * 2,
      memberMonthlyVolumeIp,
      shopperMonthlyVolumeIp,
      totalMonthlyVolumeIp,
      capped: capReason !== undefined,
      capReason,
    };
  });
}

export function estimateLevelDistribution(
  network: AggregateYearSnapshot[],
  inputs: SimulatorInputs,
): LevelDistribution[] {
  const states = simulateAggregateLevels(inputs, { years: network.length });
  return states.map((state) => ({
    year: state.year,
    membersByLevel: state.membersByLevel,
    shoppersByLevel: state.shoppersByLevel,
  }));
}

export function estimateRankDistribution(
  network: AggregateYearSnapshot[],
  levels: LevelDistribution[],
  inputs: SimulatorInputs,
  strategy: GrowthStrategyName,
): RankDistribution[] {
  const personalMonthlyVolume =
    inputs.personalMonthlyVolume ?? inputs.memberMonthlyVolume;
  const spread = strategy === 'standard' ? 0 : strategy === 'dirichlet' ? 0.18 : 0.28;

  return network.map((snapshot, yearIndex) => {
    const level = levels[yearIndex];
    const membersByLevel = level?.membersByLevel ?? [];

    return {
      year: snapshot.year,
      byLevel: membersByLevel.map((membersAtLevel, levelIndex) => {
        const subtreeMembers = sum(membersByLevel.slice(levelIndex + 1));
        const qgvPerNode =
          membersAtLevel > 0
            ? Math.max(0, snapshot.totalMonthlyVolumeIp * (subtreeMembers / snapshot.activeMembers) / membersAtLevel)
            : 0;
        const qualifiedLegs = Math.min(
          inputs.maxDirectMembersPerMember ?? 29,
          Math.max(0, (membersByLevel[levelIndex + 1] ?? 0) / Math.max(1, membersAtLevel)),
        );
        return estimateRankShares({
          av: personalMonthlyVolume,
          qgv: qgvPerNode,
          qualifiedLegs,
          spread,
        });
      }),
    };
  });
}

export function estimatePhase1Provision(
  network: AggregateYearSnapshot[],
  ranks: RankDistribution[],
  inputs: SimulatorInputs,
): PhaseProvisionByYear[] {
  return network.map((snapshot, index) => {
    const qualificationShare = estimatePhase1QualificationShare(ranks[index]);
    const shopperUnits =
      snapshot.shopperMonthlyVolumeIp *
      MONTHS_PER_YEAR *
      (PHASE1.shop.level1 + PHASE1.shop.level2 + PHASE1.shop.level3) *
      qualificationShare;
    const firstMemberSlice =
      Math.min(inputs.memberMonthlyVolume, REFERRAL_THRESHOLD_IP) *
      snapshot.activeMembers *
      MONTHS_PER_YEAR *
      (PHASE1.referral.level1 + PHASE1.referral.level2 + PHASE1.referral.level3) *
      qualificationShare;
    const restMemberSlice =
      Math.max(0, inputs.memberMonthlyVolume - REFERRAL_THRESHOLD_IP) *
      snapshot.activeMembers *
      MONTHS_PER_YEAR *
      (PHASE1.shopDiscount.level1 + PHASE1.shopDiscount.level2 + PHASE1.shopDiscount.level3) *
      qualificationShare;

    return {
      year: snapshot.year,
      total: shopperUnits + firstMemberSlice + restMemberSlice,
    };
  });
}

export function estimatePhase2Phase3Provision(
  network: AggregateYearSnapshot[],
  ranks: RankDistribution[],
): { phase2: PhaseProvisionByYear[]; phase3: PhaseProvisionByYear[] } {
  const phase2 = network.map((snapshot, index) => {
    const rankShare = averageQualifiedShare(ranks[index], [
      'Bronze',
      'Silver',
      'Gold',
      'Diamond',
      '1*Diamond',
      '2*Diamond',
      '3*Diamond',
    ]);
    return {
      year: snapshot.year,
      total: snapshot.totalMonthlyVolumeIp * MONTHS_PER_YEAR * 0.09 * rankShare,
    };
  });
  const phase3 = network.map((snapshot, index) => {
    const rankShare = averageQualifiedShare(ranks[index], [
      '1*Diamond',
      '2*Diamond',
      '3*Diamond',
    ]);
    return {
      year: snapshot.year,
      total: snapshot.totalMonthlyVolumeIp * MONTHS_PER_YEAR * 0.08 * rankShare,
    };
  });

  return { phase2, phase3 };
}

export function estimateRootProvision(
  network: AggregateYearSnapshot[],
  ranks: RankDistribution[],
  phase1: PhaseProvisionByYear[],
  phase23: { phase2: PhaseProvisionByYear[]; phase3: PhaseProvisionByYear[] },
): RootProvisionByYear[] {
  return network.map((snapshot, index) => {
    const rootRankShares = ranks[index]?.byLevel[0] ?? { Member: 1 };
    const rootRankName = strongestRank(rootRankShares);
    const rootCaptureShare = Math.min(1, 0.08 + Math.log10(snapshot.activeMembers + 1) / 12);

    return {
      year: snapshot.year,
      rankName: rootRankName,
      total:
        phase1[index].total * rootCaptureShare +
        phase23.phase2[index].total * rootCaptureShare +
        phase23.phase3[index].total * rootCaptureShare,
    };
  });
}

export function buildChartSeries(
  network: AggregateYearSnapshot[],
  phase1: PhaseProvisionByYear[],
  phase23: { phase2: PhaseProvisionByYear[]; phase3: PhaseProvisionByYear[] },
  root: RootProvisionByYear[],
  inputs: SimulatorInputs,
): ChartDataPoint[] {
  const unitToCurrency = inputs.unitToCurrency ?? 1;

  return network.map((snapshot, index) => ({
    year: snapshot.year,
    members: snapshot.activeMembers,
    shoppers: snapshot.activeShoppers,
    monthlyVolumeEur: snapshot.totalMonthlyVolumeIp * unitToCurrency,
    monthlyProvisionEur:
      ((phase1[index]?.total ?? 0) +
        (phase23.phase2[index]?.total ?? 0) +
        (phase23.phase3[index]?.total ?? 0)) *
      unitToCurrency /
      MONTHS_PER_YEAR,
    rootProvisionEur: (root[index]?.total ?? 0) * unitToCurrency / MONTHS_PER_YEAR,
    capped: snapshot.capped,
    capReason: snapshot.capReason,
  }));
}

function estimateRankShares(input: {
  av: number;
  qgv: number;
  qualifiedLegs: number;
  spread: number;
}): Record<string, number> {
  if (input.spread <= 0) {
    return {
      [determineRank({
        av: input.av,
        qgv: input.qgv,
        qualifiedLegs: input.qualifiedLegs,
        bronzeLegs: input.qualifiedLegs,
        diamondLegs: input.qualifiedLegs >= 12 ? Math.floor(input.qualifiedLegs / 4) : 0,
      }).name]: 1,
    };
  }

  const thresholds = [
    ...PRELIM_RANKS,
    ...PHASE2_RANKS,
    ...PHASE3_RANKS.map((rank) => ({
      name: rank.name,
      minAV: rank.minAV,
      minQGV: rank.minQGV,
      minQL: rank.minQL,
    })),
  ];
  const shares: Record<string, number> = { Member: 1 };

  for (const rank of thresholds) {
    const qgvProbability = smoothThreshold(input.qgv, rank.minQGV, input.spread);
    const qlProbability = smoothThreshold(input.qualifiedLegs, rank.minQL, input.spread);
    const avProbability = input.av >= rank.minAV ? 1 : 0;
    shares[rank.name] = qgvProbability * qlProbability * avProbability;
  }

  return normalizeRankShares(shares);
}

function smoothThreshold(value: number, threshold: number, spread: number): number {
  if (threshold <= 0) return 1;
  const width = Math.max(1, threshold * spread);
  return 1 / (1 + Math.exp(-(value - threshold) / width));
}

function normalizeRankShares(shares: Record<string, number>): Record<string, number> {
  const rankOrder = [
    'Member',
    'Believer',
    'Builder',
    'Bronze',
    'Silver',
    'Gold',
    'Diamond',
    '1*Diamond',
    '2*Diamond',
    '3*Diamond',
  ];
  const result: Record<string, number> = {};
  let higherShare = 0;

  for (let index = rankOrder.length - 1; index >= 0; index--) {
    const rank = rankOrder[index];
    const cumulative = Math.max(0, Math.min(1, shares[rank] ?? 0));
    result[rank] = Math.max(0, cumulative - higherShare);
    higherShare = Math.max(higherShare, cumulative);
  }

  const total = sum(Object.values(result));
  if (total <= 0) return { Member: 1 };

  for (const rank of Object.keys(result)) {
    result[rank] = (result[rank] ?? 0) / total;
  }

  return result;
}

function estimatePhase1QualificationShare(ranks?: RankDistribution): number {
  if (!ranks) return 1;
  const shares = ranks.byLevel.flatMap((level) => [
    level.Believer ?? 0,
    level.Builder ?? 0,
    level.Bronze ?? 0,
    level.Silver ?? 0,
    level.Gold ?? 0,
    level.Diamond ?? 0,
    level['1*Diamond'] ?? 0,
    level['2*Diamond'] ?? 0,
    level['3*Diamond'] ?? 0,
  ]);
  if (shares.length === 0) return 1;
  return Math.max(0.1, sum(shares) / shares.length);
}

function averageQualifiedShare(ranks: RankDistribution | undefined, names: string[]): number {
  if (!ranks) return 0;
  const shares = ranks.byLevel.map((level) =>
    names.reduce((total, name) => total + (level[name] ?? 0), 0),
  );
  if (shares.length === 0) return 0;
  return sum(shares) / shares.length;
}

function strongestRank(shares: Record<string, number>): string {
  return Object.entries(shares).reduce(
    (best, current) => (current[1] > best[1] ? current : best),
    ['Member', 0],
  )[0];
}

function addAtLevel(values: number[], level: number, count: number): void {
  if (count <= 0) return;
  values[level] = (values[level] ?? 0) + count;
}

function simulateAggregateLevels(
  inputs: SimulatorInputs,
  options: { years?: number; applyChurnFloor?: boolean } = {},
): Array<{ year: number; membersByLevel: number[]; shoppersByLevel: number[] }> {
  const years = options.years ?? SIMULATION_YEARS;
  const maxDirectMembers = Math.max(1, inputs.maxDirectMembersPerMember ?? 29);
  const duplicationRate = Math.max(0, inputs.duplicationRate);
  const attritionRate = options.applyChurnFloor === true
    ? applyMandatoryChurnFloor(
        inputs.membersPerYear,
        Math.max(0, Math.min(1, inputs.attritionRate)),
      )
    : Math.max(0, Math.min(1, inputs.attritionRate));
  const membersByLevel: number[] = [];
  const shoppersByLevel: number[] = [];
  const states: Array<{ year: number; membersByLevel: number[]; shoppersByLevel: number[] }> = [];

  for (let yearIndex = 0; yearIndex < years; yearIndex++) {
    for (let level = 1; level < membersByLevel.length; level++) {
      membersByLevel[level] = Math.max(0, (membersByLevel[level] ?? 0) * (1 - attritionRate));
    }
    for (let level = 0; level < shoppersByLevel.length; level++) {
      shoppersByLevel[level] = Math.max(0, (shoppersByLevel[level] ?? 0) * (1 - attritionRate));
    }

    const sourceMembersByLevel = membersByLevel.slice();
    const directMemberCapacity = Math.max(
      0,
      maxDirectMembers - (membersByLevel[0] ?? 0),
    );
    const directMemberGrowth = Math.min(
      Math.max(0, inputs.membersPerYear),
      directMemberCapacity,
    );
    addAtLevel(membersByLevel, 0, directMemberGrowth);
    addAtLevel(shoppersByLevel, 0, Math.max(0, inputs.shoppersPerYear));

    const duplicatedMembersPerSource = Math.min(
      Math.max(0, inputs.membersPerYear) * duplicationRate,
      maxDirectMembers,
    );
    const duplicatedShoppersPerSource =
      Math.max(0, inputs.shoppersPerYear) * duplicationRate;

    for (let level = 0; level < sourceMembersByLevel.length; level++) {
      const sourceCount = sourceMembersByLevel[level] ?? 0;
      addAtLevel(membersByLevel, level + 1, sourceCount * duplicatedMembersPerSource);
      addAtLevel(shoppersByLevel, level + 1, sourceCount * duplicatedShoppersPerSource);
    }

    trimTrailingZeros(membersByLevel);
    trimTrailingZeros(shoppersByLevel);

    states.push({
      year: yearIndex + 1,
      membersByLevel: membersByLevel.slice(),
      shoppersByLevel: shoppersByLevel.slice(),
    });
  }

  return states;
}

function trimTrailingZeros(values: number[]): void {
  while (values.length > 0 && Math.abs(values[values.length - 1] ?? 0) < 1e-9) {
    values.pop();
  }
}

function sum(values: number[]): number {
  return values.reduce((total, value) => total + value, 0);
}
