import { describe, expect, it } from 'vitest';
import { resolve } from 'node:path';
import { runSimulation, type SimulationMode } from '@mlm/simulator-core';
import { lifeplusProduct } from '@mlm/product-lifeplus';
import { writeCsv } from '../shared/csv-writer';
import { B1_PARAMETER_SETS } from './parameter-sets';
import {
  buildChartSeries,
  estimateLevelDistribution,
  estimateNetworkAggregate,
  estimatePhase1Provision,
  estimatePhase2Phase3Provision,
  estimateRankDistribution,
  estimateRootProvision,
} from './algorithms/aggregate-engine';

const TOTAL_MONTHS = 120;
const QUALITY_SET_IDS = new Set(['P1', 'P2', 'P4']);

interface QualityRow {
  benchmark_id: string;
  parameter_set: string;
  strategy: string;
  seed: string;
  year: number;
  aggregate_members: number;
  tree_members: number;
  members_diff_pct: number;
  aggregate_shoppers: number;
  tree_shoppers: number;
  shoppers_diff_pct: number;
  aggregate_monthly_volume_ip: number;
  tree_monthly_volume_ip: number;
  volume_diff_pct: number;
  aggregate_root_monthly_provision: number;
  tree_root_monthly_provision: number;
  root_provision_diff_pct: number;
  aggregate_rank: string;
  tree_rank: string;
  quality_class: 'Exact' | 'Expected' | 'Projected' | 'Capped';
  passed: boolean;
  notes: string;
}

describe('B1-Q aggregate path quality benchmark', () => {
  it(
    'writes aggregate-vs-tree drift results for capped decision making',
    () => {
      const rows: QualityRow[] = [];

      for (const parameterSet of B1_PARAMETER_SETS.filter((set) =>
        QUALITY_SET_IDS.has(set.id),
      )) {
        const aggregate = runAggregate(parameterSet.inputs);
        const tree = runSimulation(
          lifeplusProduct,
          parameterSet.inputs,
          TOTAL_MONTHS,
          { simulationMode: 'person-tree' satisfies SimulationMode },
        );

        for (const [index, aggregatePoint] of aggregate.chart.entries()) {
          const treeYear = tree.yearEnds[index];
          if (!treeYear) continue;

          const treeMonthlyVolume =
            treeYear.members * parameterSet.inputs.memberMonthlyVolume +
            treeYear.shoppers * parameterSet.inputs.shopperMonthlyVolume;
          const aggregateRootProvision = aggregatePoint.rootProvisionEur;
          const treeRootProvision = treeYear.totalEUR / 12;
          const row = {
            benchmark_id: 'B1-Q',
            parameter_set: parameterSet.id,
            strategy: 'standard',
            seed: 'none',
            year: aggregatePoint.year,
            aggregate_members: round(aggregatePoint.members),
            tree_members: round(treeYear.members),
            members_diff_pct: pctDiff(aggregatePoint.members, treeYear.members),
            aggregate_shoppers: round(aggregatePoint.shoppers),
            tree_shoppers: round(treeYear.shoppers),
            shoppers_diff_pct: pctDiff(aggregatePoint.shoppers, treeYear.shoppers),
            aggregate_monthly_volume_ip: round(aggregatePoint.monthlyVolumeEur),
            tree_monthly_volume_ip: round(treeMonthlyVolume),
            volume_diff_pct: pctDiff(aggregatePoint.monthlyVolumeEur, treeMonthlyVolume),
            aggregate_root_monthly_provision: round(aggregateRootProvision),
            tree_root_monthly_provision: round(treeRootProvision),
            root_provision_diff_pct: pctDiff(aggregateRootProvision, treeRootProvision),
            aggregate_rank: aggregate.root[index]?.rankName ?? 'unknown',
            tree_rank: treeYear.rankName,
            quality_class: classify({
              membersDiffPct: pctDiff(aggregatePoint.members, treeYear.members),
              shoppersDiffPct: pctDiff(aggregatePoint.shoppers, treeYear.shoppers),
              volumeDiffPct: pctDiff(aggregatePoint.monthlyVolumeEur, treeMonthlyVolume),
              rootProvisionDiffPct: pctDiff(aggregateRootProvision, treeRootProvision),
              capped: aggregatePoint.capped,
            }),
            passed: false,
            notes: parameterSet.purpose,
          } satisfies QualityRow;

          row.passed = row.quality_class !== 'Capped' && row.quality_class !== 'Projected';
          rows.push(row);
        }
      }

      writeCsv(
        resolve('benchmarks/results/2026-06/b1-quality-results.csv'),
        rows,
      );

      expect(rows.length).toBeGreaterThan(0);
    },
    180_000,
  );
});

function runAggregate(inputs: (typeof B1_PARAMETER_SETS)[number]['inputs']) {
  const network = estimateNetworkAggregate(inputs);
  const levels = estimateLevelDistribution(network, inputs);
  const ranks = estimateRankDistribution(network, levels, inputs, 'standard');
  const phase1 = estimatePhase1Provision(network, ranks, inputs);
  const phase23 = estimatePhase2Phase3Provision(network, ranks);
  const root = estimateRootProvision(network, ranks, phase1, phase23);
  const chart = buildChartSeries(network, phase1, phase23, root, inputs);
  return { network, levels, ranks, phase1, phase23, root, chart };
}

function classify(input: {
  membersDiffPct: number;
  shoppersDiffPct: number;
  volumeDiffPct: number;
  rootProvisionDiffPct: number;
  capped: boolean;
}): QualityRow['quality_class'] {
  if (input.capped) return 'Capped';
  if (
    input.membersDiffPct >= 5 ||
    input.shoppersDiffPct >= 5 ||
    input.volumeDiffPct >= 2 ||
    input.rootProvisionDiffPct >= 25
  ) {
    return 'Projected';
  }
  if (
    input.membersDiffPct >= 1 ||
    input.shoppersDiffPct >= 1 ||
    input.volumeDiffPct >= 0.5 ||
    input.rootProvisionDiffPct >= 10
  ) {
    return 'Expected';
  }
  return 'Exact';
}

function pctDiff(aggregate: number, exact: number): number {
  if (exact === 0) return aggregate === 0 ? 0 : 100;
  return round((Math.abs(aggregate - exact) / Math.abs(exact)) * 100);
}

function round(value: number): number {
  return Math.round(value * 1000) / 1000;
}
